package com.vocera.challenge.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vocera.challenge.domain.TokenDomain;
import com.vocera.challenge.service.ChallengeService;

@RestController
@RequestMapping("/api")
public class Resource {

    @Autowired
    private ChallengeService service;
    public static final String START = "START";
    @GetMapping(value = "/start", produces = "Application/Json")
    public ResponseEntity<TokenDomain> getToken() {

        return new ResponseEntity<TokenDomain>(new TokenDomain(START, service.saveRandomNumber()), HttpStatus.OK);
    }

    @GetMapping(value = "/v1/{token}/{input}", produces = "Application/Json")
    public ResponseEntity<?> getTotalScore(
            @PathVariable int token, @PathVariable String input) {
        return service.letsPlay(token, input.toLowerCase(), "V1");
    }

    @GetMapping(value = "/v2/{token}/{input}", produces = "Application/Json")
    public ResponseEntity<?> getTotalScoreServerSide(
            @PathVariable int token, @PathVariable String input) {
        return service.letsPlay(token, input.toLowerCase(), "V2");
    }
}

