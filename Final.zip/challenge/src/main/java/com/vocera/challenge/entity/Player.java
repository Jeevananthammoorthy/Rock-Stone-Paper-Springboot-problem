package com.vocera.challenge.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Player")
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private int token;

    private String serverRecentMove;

    private int playertotalScore;

    private int servertotalScore;

    public int getToken() {
        return token;
    }

    public void setToken(int token) {
        this.token = token;
    }

    public String getServerRecentMove() {
        return serverRecentMove;
    }

    public void setServerRecentMove(String serverRecentMove) {
        this.serverRecentMove = serverRecentMove;
    }

    public int getPlayertotalScore() {
        return playertotalScore;
    }

    public void setPlayertotalScore(int playertotalScore) {
        this.playertotalScore = playertotalScore;
    }

    public int getServertotalScore() {
        return servertotalScore;
    }

    public void setServertotalScore(int servertotalScore) {
        this.servertotalScore = servertotalScore;
    }
}
