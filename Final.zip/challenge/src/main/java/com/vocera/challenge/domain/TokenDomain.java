package com.vocera.challenge.domain;

public class TokenDomain {

    private String status;
    private int random;

    public TokenDomain(String status, int random) {
        super();
        this.status = status;
        this.random = random;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getRandom() {
        return random;
    }

    public void setRandom(int random) {
        this.random = random;
    }
}
