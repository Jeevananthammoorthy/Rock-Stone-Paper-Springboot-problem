package com.vocera.challenge.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vocera.challenge.domain.ServerDomain;
import com.vocera.challenge.entity.Player;
import com.vocera.challenge.entity.PlayerRepository;

@Service
@Transactional
public class ChallengeService {

    @Autowired
    private PlayerRepository playerRepository;
    HashMap<String, String> hm = new LinkedHashMap<>();
    String[] possibleValue = { "scissors", "rock", "paper" };

    public int saveRandomNumber() {
        Player entity = new Player();
        entity.setToken(new Random().nextInt(Integer.MAX_VALUE));
        playerRepository.save(entity);
        return entity.getToken();
    }

    public ResponseEntity<?> letsPlay(int token, String input, String version) {
        Player result = retrivePlayerDetailByToken(token);
        if (Arrays.asList(possibleValue).contains(input) && Objects.nonNull(result)) {
            int playerValue = result.getPlayertotalScore();
            int serverValue = result.getServertotalScore();
            hm.put("rock", "scissors");
            hm.put("scissors", "paper");
            hm.put("paper", "rock");
        ServerDomain obj = new ServerDomain();
        String random = possibleValue[new Random().nextInt(3)];
            obj.setServerMove(random);
            result.setServerRecentMove(random);
            if (version.equalsIgnoreCase("V1")) {
                if (hm.get(input).equalsIgnoreCase(random)) {
                    playerValue++;
                    result.setPlayertotalScore(playerValue);
                } else if (hm.get(random).equalsIgnoreCase(input)) {
                    serverValue++;
                    result.setServertotalScore(serverValue);
                }
            } else {
                if (input.equals(random)) {
                    obj.setServerMove(hm.get(input));
                } else if (hm.get(input).equalsIgnoreCase(random)) {
                    obj.setServerMove(hm.get(random));
                }
                serverValue++;
                result.setServertotalScore(serverValue);
            }
            if (3 == serverValue) {
                deletePlayerDetailByToken(token);
                return new ResponseEntity<>(new String("GAME ENDED, SERVER WON THE GAME"), HttpStatus.OK);
            } else if (3 == playerValue) {
                deletePlayerDetailByToken(token);
                return new ResponseEntity<>(new String("GAME ENDED, PLAYER WON THE GAME"), HttpStatus.OK);
            }
            savePlayerDetail(result);
            obj.setTotalScore(serverValue);
            return new ResponseEntity<ServerDomain>(obj, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    private Player retrivePlayerDetailByToken(int token) {
        return playerRepository.findByToken(token);
    }

    private Long deletePlayerDetailByToken(int token) {
        return playerRepository.removeByToken(token);
    }

    private void savePlayerDetail(Player player) {
        playerRepository.save(player);
    }
}
