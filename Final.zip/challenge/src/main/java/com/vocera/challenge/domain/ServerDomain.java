package com.vocera.challenge.domain;

public class ServerDomain {
    private String serverMove;
    private int totalScore;

    public String getServerMove() {
        return serverMove;
    }

    public void setServerMove(String serverMove) {
        this.serverMove = serverMove;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

}
