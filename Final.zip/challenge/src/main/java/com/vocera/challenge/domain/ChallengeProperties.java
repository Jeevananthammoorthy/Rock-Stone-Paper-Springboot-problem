package com.vocera.challenge.domain;

public class ChallengeProperties {

}
